Teste MSCode

Este site se baseia em um formulário de pesquisa que consiste em esclarecer duvidas da empresa em questão. Foi utilizado perguntas objetivas e diretas de forma simples... seus campos e espaços forma ajustado ao tamanho da tela podendo se alterar aultomaticamente, dependedo do dispositivo a ser utilizado sendo mobile ou desktop.