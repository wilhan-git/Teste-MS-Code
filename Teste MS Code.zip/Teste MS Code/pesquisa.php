<?php
            echo "Nome: ". $_POST["nome"]<br>;

            echo "Cidade: ". $_POST["cidade"] <br>;

            echo "Questao 2: ". $_POST["questao2"] <br>;

            echo "questao 10: ". $_POST["questao10"] <br>;


               
?>

